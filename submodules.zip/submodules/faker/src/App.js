import "./App.css";
import PersonInfo from "./components/Home";
import { faker } from "@faker-js/faker";
import ApprovalCard from "./components/ApprovalCard";

function App() {
  return (
    <>
      <ApprovalCard>
        <PersonInfo
          author="Thanh Hoang"
          date="06/06/2022"
          text="Hello"
          avatar={faker.image.image()}
        />
      </ApprovalCard>

      <PersonInfo
        author="Phuc Do"
        date="06/07/2022"
        text="Hello"
        avatar={faker.image.image()}
      />

      <PersonInfo
        author="Aloha"
        date="06/06/2012"
        text="Hello there"
        avatar={faker.image.image()}
      />
    </>
  );
}

export default App;
